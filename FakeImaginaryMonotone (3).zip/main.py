name = 'Firuza'
print(name)
age = 43
print(age)
new_age = 40
print(new_age)
Is_Student = 'True'
print(Is_Student)