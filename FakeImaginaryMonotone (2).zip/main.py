name = 'Firuza'
print('Firuza')
age = 43
print(43)
new_age = 40
print(40)
Is_Student = 'True'
print('True')